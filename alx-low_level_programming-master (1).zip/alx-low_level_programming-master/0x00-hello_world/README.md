Preprocessing, Compiling and assembling of codes using the C language
