nested loops
