#include <stdio.h>
/**
 * main - Print numbers in base 10
 *
 * Return: 0
 */
int main(void)
{
	printf("0123456789\n");
	return (0);
}
