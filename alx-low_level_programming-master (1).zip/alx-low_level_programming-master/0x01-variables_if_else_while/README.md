C variables
